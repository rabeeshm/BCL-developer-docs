videojs.plugin('redispatchEnded', function() {
  var player = this;
  window.postMessage('talking across an iframe!', '*');
});