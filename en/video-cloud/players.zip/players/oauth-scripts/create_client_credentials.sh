#!/bin/bash

# the BC_TOKEN you've retreived.  See OAuth Guide for details.
bc_token=$1
# the publisher ID you'd like the credentials under
publisher_id=$2
# the operation to given access to
operation=$3

if [ -z "$bc_token" ] || [ -z "$publisher_id" ] || [ -z "$operation" ]
then
    echo "usage: create_client_credentials <bc_token> <publisher_id> <operation>"
    exit 1;
fi

credentials=`curl -k -i -H "Authorization: BC_TOKEN $bc_token" -d "name=created_by_script&maximum_scope=[{\"identity\":{\"type\":\"video-cloud-account\",\"account-id\": $publisher_id},\"operations\":[\"$operation\"]}]\"" https://oauth.brightcove.com/v2/client_credentials`

if [[ "$?" -eq "0" ]] ;then
  client_id=`echo $credentials | grep -o '"client_id":"\([a-zA-Z0-9-]\+\)"' | cut -d : -f2 | tr -d '"'`
  client_secret=`echo $credentials | grep -o '"client_secret":"\([_a-zA-Z0-9-]\+\)"' | cut -d : -f2 | tr -d '"'`

  update_command="curl -s -L http://players.brightcove.com/docs/alpha/create_access_token.sh | bash -s $client_id $client_secret"

  echo ""
  echo "Client ID: $client_id"
  echo "Client Secret: $client_secret"
  echo ""
  echo "Run the following command to set your Brightcove access token."
  echo "Tokens expire every 5 minutes. Running this again will set a new token."
  echo ""
  echo "export BC_ACCESS_TOKEN=\`$update_command\` && echo 'Token has been updated'"
  echo ""
else
  echo ""
  echo "An error has occurred.  See the output above for details."
fi
