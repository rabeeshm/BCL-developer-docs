#!/bin/bash

client_id=$1
client_secret=$2

if [ -z "$client_id" ] || [ -z "$client_secret" ]
then
    echo "To use, you must add a client_id and client_secret value to the script"
    exit 1;
fi

# get a JSON reponse that should contain an access token
token_output=`curl -k -s --user $client_id:$client_secret -d 'grant_type=client_credentials' https://oauth.brightcove.com/v2/access_token`

# grab the access token from the response
token=`echo $token_output | cut -f 4 -d \"`

# check to see if the access token if is as long as we expect.  If it's not, then
# print the full response (which should have error info in it).
token_len=$(echo ${#token})
if [ $token_len -lt 20 ]; then
    echo "$token_output"
else
    echo "$token"
fi
