# Player Management API v1

Player Management refers to the creation, editing and management of players as a resource to publishers. Player Management is achieved by a REST API that allow its consumers to create, configure, preview and publish player instances.

Creating and updating players is now done in a two-phased approach. Rather than having all changes automatically apply to production players we have separated these changes into preview and published. You can now make all of the updates that you wish to your preview player without affecting what your end users see. You can choose to publish the changes whenever you would like.

The Player Management API allows a user to:

1. create a player
2. view the settings of a player
3. change the settings of a player
4. list all the players associated with the publisher
5. publish a player to make it available to the consumer

## <a id="glossary"></a>Glossary of terms used in this document

* {accountId}: A placeholder for the Brightcove publisher's account number.
* {playerId}: A placeholder for the ID generated when a new player is created. This is a unique identifier which will be used in all player-specific API calls.
* {accessToken}: A placeholder which should be replaced with the access token generated in the "Getting Started" section of this guide.
* {versionNumber} : A placeholder which should be replaced with the current version of the Player Management API. This is found at the top of this guide.
* player skin: A base player that decides the appearance of the final player created.
* player settings / configuration: These are the options applied to the player skin that will create a new player based on configuration points specified in the source player. The configuration is a JSON object containing all the settings for a particular player.

## Base URL

The base URL for the Player Management API is:

    http://players.api.brightcove.com/v1a

## <a id="configuration"></a>Configuration options

In order to create a player more advanced than just the player skin, you must provide a configuration. The following JSON is an example to show the format and data types of the possible settings in the current version of the Player Management API.

    {
      "name" : STRING,  // The only field currently required - the Player Name in the UI
      "description" : STRING,
      "configuration" : { 
        "player" : {
          "autoplay" : BOOLEAN
        },
        "media" : { 
          "name" : STRING,          
          "sources" : [{ 
            "type" : STRING(one of: "video/mp4", "video/webm" or  "video/ogg"),
            "src" : STRING(e.g. "http://video-js.zencoder.com/oceans-clip.mp4")
          }],
          "poster" : {
            "highres" : STRING(e.g. "http://www.videojs.com/img/poster.jpg"
          }
        }
      }
    }

### NOTE
The definition above for media sources is our intended implementation.  The current 
alpha, however, expects a single media.src URL string instead of the media.sources array.  For example:
    
    "media" : { 
        "name" : STRING,
        "src" : STRING(e.g. "http://video-js.zencoder.com/oceans-clip.mp4")
    }

As you can see in the example above, a direct link to a video file must be given. We expect to have more options in the future, but for now please follow these steps to get a direct link to media:

* Sign into the Studio and go to the Media Module
* Go to the video you wish to use, click "Edit"
* Go to the "Video Files" tab
* Select a rendition from the "Renditions List", then 'Copy link' under the "Rendition URL" on the right

If you wish to create a new player using one of your existing players as a template you can include (at the same level as "name"):

    "template": { "id" : "(id of player)" }
    
## Error messages

Error messages are returned using the response status codes of a request to the API. Status Codes correspond to those defined by W3. Some of the most commonly seen codes are:

* 200 Request success
* 201 Created (a player, a configuration)
* 400 Bad request - the syntax of the API call is likely incorrect
* 401 Unauthorized - check that you have followed the oauth instructions correctly.
* 404 Not found - check the resource exists and the URL used in the API call is correct
* 500 Internal Server Error - there was an error trying to fulfil the request


## <a name="limitations"></a>Limitations

* There is currently no way to delete a player.
* The Player Management APIs are not yet available via HTTPS.
* Currently only Player IDs and URLs are returned as a result of a list call. In the future, it will include player metadata e.g. name, description.
* Updating the configuration of a player with the same configuration(and therefore changing nothing) will result in an error. In the future this will return a 304(Not Modified) but currently returns: { "killed": false, "code": 1, "signal": null }
